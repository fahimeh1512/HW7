package com.example.hw7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button mRedButton;
    Button mOrangeButton;
    Button mYellowButton;
    Button mGreenButton;
    Button mBlueButton;
    Button mIndigoButton;
    Button mVioletButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViews();

        setListener();
    }

    public void findViews() {
        mRedButton = findViewById(R.id.red_button);
        mOrangeButton = findViewById(R.id.orange_button);
        mYellowButton = findViewById(R.id.yellow_button);
        mGreenButton = findViewById(R.id.green_button);
        mBlueButton = findViewById(R.id.blue_button);
        mIndigoButton = findViewById(R.id.indigo_button);
        mVioletButton = findViewById(R.id.violet_button);
    }

    public void setListener() {
        mRedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hideButton(view);
                changeText(view);
            }
        });

        mOrangeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hideButton(view);
                changeText(view);
            }
        });

        mYellowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hideButton(view);
                changeText(view);
            }
        });

        mGreenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hideButton(view);
                changeText(view);
            }
        });

        mBlueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hideButton(view);
                changeText(view);
            }
        });

        mIndigoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hideButton(view);
                changeText(view);
            }
        });

        mVioletButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hideButton(view);
                changeText(view);
            }
        });
    }

    public void hideButton(View view) {
        ViewGroup parentView = (ViewGroup) view.getParent();
        parentView.removeView(view);

        // Or this...
        //view.setVisibility(View.GONE);

    }

    // Changes text of all buttons.
    public void changeText(View view) {
            setTextForButton(view, mRedButton);
            setTextForButton(view, mOrangeButton);
            setTextForButton(view, mYellowButton);
            setTextForButton(view, mGreenButton);
            setTextForButton(view, mBlueButton);
            setTextForButton(view, mIndigoButton);
            setTextForButton(view, mVioletButton);
    }

    public void setTextForButton(View view, final Button colorButton) {
        Button button = (Button) view;
        // Saves text of each button to return it after 5 seconds.
        final CharSequence oldText = colorButton.getText();

        colorButton.setText(button.getText());

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                colorButton.setText(oldText);
            }
        }, 5000);
    }
}