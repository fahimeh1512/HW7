import java.util.InputMismatchException;
import java.util.Scanner;

public class Diamond {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int number = 1;

        try {
            number = scanner.nextInt();

        } catch(InputMismatchException exception)
        {
            System.out.println("This is not an integer. So we make diamond with number: 1");
        }

        makeDiamond(number);
    }

    public static void makeDiamond(int number) {
        int diameter = 2 * number + 1;
        // Square dimensions must be odd.
        int squareDimension = number % 2 == 0 ? number - 1 : number;
        int startOfSquare = diameter / 2 + 1 - (squareDimension / 2);
        int squareCounter = 0;
        int countOfStars = 1;
        int remainedStars;
        boolean ascendingFlag = true;

        for (int i = 1; i <= diameter; i++) {
            for (int j = 0; j < (diameter - countOfStars) / 2; j++)
                System.out.print(" ");

            // Empty square scope.
            if (i == startOfSquare && squareCounter++ < squareDimension) {
                remainedStars = (countOfStars - squareDimension) / 2;
                for (int l = 0; l < remainedStars; l++)
                    System.out.print("*");
                for (int l = 0; l < squareDimension; l++)
                    System.out.print(" ");
                for (int l = 0; l < remainedStars; l++)
                    System.out.print("*");
                startOfSquare++;
            }
            // An complete line of stars.
            else
                for (int j = 0; j < countOfStars; j++)
                    System.out.print("*");

            // In up half of diamond stars must be plussed in every loop
            // but in down half of diamond it is reverse.
            if (countOfStars < diameter && ascendingFlag)
                countOfStars += 2;
            else {
                ascendingFlag = false;
                countOfStars -= 2;
            }

            // Goes to next line.
            System.out.println();
        }
    }
}
